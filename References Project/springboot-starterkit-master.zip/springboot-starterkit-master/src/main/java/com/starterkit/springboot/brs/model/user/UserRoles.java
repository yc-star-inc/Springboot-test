package com.starterkit.springboot.brs.model.user;

/**
 * Created by Arpit Khandelwal.
 */
public enum UserRoles {
    ADMIN, PASSENGER
}
