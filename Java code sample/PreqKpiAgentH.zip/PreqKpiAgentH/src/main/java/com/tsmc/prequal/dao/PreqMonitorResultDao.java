package com.tsmc.prequal.dao;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;
import org.springframework.stereotype.Repository;

import com.tsmc.prequal.data.model.mapper.RawmatMonitorResultMapper;
import com.tsmc.prequal.data.model.po.RawmatMonitorResult;
import com.tsmc.prequal.data.model.po.RawmatPreBatchStatus;
import com.tsmc.prequal.demo.po.Sale;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import javax.sql.DataSource;

@Repository
public class PreqMonitorResultDao {

	private Logger LOG = LoggerFactory.getLogger(PreqMonitorResultDao.class);
	
	@Autowired
	private NamedParameterJdbcTemplate jdbcTemplate;

//	@Autowired
//	private NamedParameterJdbcTemplate namedJdbcTemplate;

	private String tableNameString = "ppmsdm.rawmat_monitor_result";

	private String findAllSqlString = String.format("select * from %s", tableNameString);

	public PreqMonitorResultDao(NamedParameterJdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	public List<RawmatMonitorResult> findAll() {

		List<RawmatMonitorResult> batchStatusLst = jdbcTemplate.query(findAllSqlString,
				(new RawmatMonitorResultMapper()));

		return batchStatusLst;
	}

	public List<RawmatMonitorResult> findTopNByJobStatusAndDataType(List<Integer> _jobStatus) {

		SqlParameterSource parameters = new MapSqlParameterSource().addValue("jobStatus", _jobStatus);
		
		//String inSql = String.join(",", Collections.nCopies(_jobStatus.size(), "?"));

		String whereClause = String.format("where MEAS_DATA_TYPE in ('FAC') and job_status in (:jobStatus) "
				+ " order by last_chk_dt " + " fetch first 3 rows only");
		String sqlString = String.format("%s %s", findAllSqlString, whereClause);

		List<RawmatMonitorResult> batchStatusLst = jdbcTemplate.query(sqlString, parameters,
				(new RawmatMonitorResultMapper()));

		// List<RawmatMonitorResult> batchStatusLst = jdbcTemplate.query(sqlString,
		// PreparedStatementSetter, (new RawmatMonitorResultMapper()));

//		SqlParameterSource namedParameters = new MapSqlParameterSource().addValue("jobStatus", _jobStatus);
//		return namedParameterJdbcTemplate.queryForObject(
//		  "SELECT FIRST_NAME FROM EMPLOYEE WHERE ID = :id", namedParameters, String.class);

//		@SuppressWarnings("unchecked")
//		List<RawmatMonitorResult> batchStatusLst 
//			= (List<RawmatMonitorResult>) namedJdbcTemplate.queryForObject(sqlString, namedParameters, (new RawmatMonitorResultMapper()));

		return batchStatusLst;
	}
	
	
	public List<String> findDistTopNCases(List<Integer> _jobStatus) {

		SqlParameterSource parameters = new MapSqlParameterSource().addValue("jobStatus", _jobStatus);

		String findAllSqlString = String.format("select distinct t.case_id from %s t", tableNameString);
		
		//String inSql = String.join(",", Collections.nCopies(_jobStatus.size(), "?"));

		String whereClause = String.format("where MEAS_DATA_TYPE in ('FAC') and job_status in (:jobStatus) "
				+ " order by last_chk_dt " + " fetch first 3 rows only");
		String sqlString = String.format("%s %s", findAllSqlString, whereClause);

		List<String> batchStatusLst = jdbcTemplate.query(sqlString, parameters, 
				new RowMapper<String>() {

					@Override
					public String mapRow(ResultSet rs, int rowNum) throws SQLException {
							
						LOG.info(String.format("%s -> %s", rowNum, rs.getString("CASE_ID")));
						return rs.getNString("CASE_ID"); 
					}
		});
		
		return batchStatusLst;
	}
//    select distinct t.case_id from PPMSDM.RAWMAT_MONITOR_RESULT t 
//    where t.MEAS_DATA_TYPE in ('FAC') and t.job_status in (0) 
//    order by t.last_chk_dt
//    fetch first 3 rows only

//	public void save(Sale sale) {
//		SimpleJdbcInsert insertActor = new SimpleJdbcInsert((DataSource) jdbcTemplate);
//		insertActor.withTableName(tableNameString).usingColumns("item", "quantity", "amount");
//
//		BeanPropertySqlParameterSource param = new BeanPropertySqlParameterSource(sale);
//		insertActor.execute(param);
//	}

	public RawmatMonitorResult get(int id) {
		String sql = String.format("select * from %s t where t.case_id = :caseId", tableNameString);

		SqlParameterSource parameters = new MapSqlParameterSource().addValue("caseId", id);
		
		RawmatMonitorResult sale 
			= jdbcTemplate.queryForObject(sql, parameters, BeanPropertyRowMapper.newInstance(RawmatMonitorResult.class));

		return sale;
	}

	public int update(RawmatMonitorResult _updRecord) {
		// RawmatMonitorResult
		String sql = String.format("update %s set monitor_cri=rawtohex(:monitorCriteria)" + ", last_chk_dt=sysdate"
				+ " where job_id=:jobId", tableNameString);
		// "update ppmsdm.sales set item=:item, quantity=:quantity, amount=:amount where
		// id=:id";
		//BeanPropertySqlParameterSource param = new BeanPropertySqlParameterSource(_updRecord);

		SqlParameterSource namedParameters 
		= new MapSqlParameterSource()
			.addValue("monitorCriteria", _updRecord.getMonitorCriteria())
			.addValue("jobId", _updRecord.getJobId());
		
		//NamedParameterJdbcTemplate template = new NamedParameterJdbcTemplate(jdbcTemplate);
		int rowAffected = jdbcTemplate.update(sql, namedParameters);
		return rowAffected; 
	}

	public void deleteSale(int id) {

		SqlParameterSource parameters = new MapSqlParameterSource().addValue("id", id);

		String sql = "delete from ppmsdm.sales where id = :id";
		int delRslt = jdbcTemplate.update(sql, parameters);
	}

	public void deleteSaleByItemName(String _item) {
		
		SqlParameterSource parameters = new MapSqlParameterSource().addValue("item", _item);
		
		String sql = "delete from ppmsdm.sales where item= :item";
		int delRslt = jdbcTemplate.update(sql, parameters);
	}

	public List<RawmatMonitorResult> findAllByCaseId(Long _caseId) {
		// TODO: [PreqMonitorResultDao] Add query by :caseId
		return null;
	}

	public List<RawmatMonitorResult> findAllByCaseIdAndDataType(Long _caseId, String _measDataType) {
		// TODO [PreqMonitorResultDao] Add query by :caseId, :meadDataType
		return null;
	}
}
