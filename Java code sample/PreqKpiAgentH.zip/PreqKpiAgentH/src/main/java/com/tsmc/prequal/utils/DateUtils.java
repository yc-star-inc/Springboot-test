package com.tsmc.prequal.utils;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;

public class DateUtils {

	public static SimpleDateFormat dateTimeFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
	
	public static String toTimeString(Timestamp _inputTimestamp) {
		
		SimpleDateFormat df = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		String timeStr = df.format(_inputTimestamp); 

		return timeStr; 
	}
	public static String toTimeString(java.util.Date _inputDate) {

		Timestamp ts = new Timestamp(_inputDate.getTime());
		return DateUtils.toTimeString(ts); 
	}
	
	public static String getCurTimeString()
	{
		//System.currentTimeMillis()
		Timestamp curTimestamp= new Timestamp(System.currentTimeMillis()); //Get System-Time
		return DateUtils.toTimeString(curTimestamp); 
	}
	
	public static Timestamp toTimeStamp(String _inTimeString) {
	
		Timestamp respTimestamp = Timestamp.valueOf(_inTimeString); 
		return respTimestamp; 
	}
	

}
