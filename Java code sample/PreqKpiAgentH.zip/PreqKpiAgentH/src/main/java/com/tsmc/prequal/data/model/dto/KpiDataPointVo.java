package com.tsmc.prequal.data.model.dto;

import java.util.Map;

public class KpiDataPointVo {
	String waferId;
	String lotId;
	String pointValue;
	String measDate;
	String ucl;
	String lcl;
	String usl;
	String lsl;
	String toolId;
	Map<String, String> ruleChkRslt; // ${ruleChkRslt-1}

	public String getWaferId() {
		return waferId;
	}

	public void setWaferId(String waferId) {
		this.waferId = waferId;
	}

	public String getLotId() {
		return lotId;
	}

	public void setLotId(String lotId) {
		this.lotId = lotId;
	}

	public String getPointValue() {
		return pointValue;
	}

	public void setPointValue(String pointValue) {
		this.pointValue = pointValue;
	}

	public String getMeasDate() {
		return measDate;
	}

	public void setMeasDate(String measDate) {
		this.measDate = measDate;
	}

	public String getUcl() {
		return ucl;
	}

	public void setUcl(String ucl) {
		this.ucl = ucl;
	}

	public String getLcl() {
		return lcl;
	}

	public void setLcl(String lcl) {
		this.lcl = lcl;
	}

	public String getUsl() {
		return usl;
	}

	public void setUsl(String usl) {
		this.usl = usl;
	}

	public String getLsl() {
		return lsl;
	}

	public void setLsl(String lsl) {
		this.lsl = lsl;
	}

	public String getToolId() {
		return toolId;
	}

	public void setToolId(String toolId) {
		this.toolId = toolId;
	}

	public Map<String, String> getRuleChkRslt() {
		return ruleChkRslt;
	}

	public void setRuleChkRslt(Map<String, String> ruleChkRslt) {
		this.ruleChkRslt = ruleChkRslt;
	}

}
