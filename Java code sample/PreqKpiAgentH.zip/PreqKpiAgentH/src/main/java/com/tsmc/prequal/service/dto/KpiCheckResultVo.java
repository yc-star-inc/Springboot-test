package com.tsmc.prequal.service.dto;

public class KpiCheckResultVo {

	private String olaStatus = "";
	private String newStatus = "";
	private String memo = "";

	public KpiCheckResultVo() {
		// TODO Auto-generated constructor stub

	}

	public String getNewStatus() {
		return newStatus;
	}

	public void setNewStatus(String newStatus) {
		this.newStatus = newStatus;
	}

	public String getOlaStatus() {
		return olaStatus;
	}

	public void setOlaStatus(String olaStatus) {
		this.olaStatus = olaStatus;
	}

	public String getMemo() {
		return memo;
	}

	public void setMemo(String memo) {
		this.memo = memo;
	}

}
