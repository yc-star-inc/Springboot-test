package com.tsmc.prequal.oldversion;

import java.util.List;

public class ResultRawVO {

	public List<SPCResultVO> getResult() {
		// TODO Auto-generated method stub
		return null;
	}

}
