package com.tsmc.prequal.service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.tsmc.prequal.data.model.po.RawmatMonitorResult;
import com.tsmc.prequal.oldversion.Constant;
import com.tsmc.prequal.oldversion.FindLeadingLotDao;
import com.tsmc.prequal.oldversion.MatMonitorResultVO;
import com.tsmc.prequal.oldversion.SPCResultVO;

/// @Component is required for scheduling
@Component
public class KpiDataService {

	private Logger logger = LoggerFactory.getLogger(KpiDataService.class);

	@Scheduled(cron = "${scheduledTasksCronPropertiesConfig.cron.expression}")
	public void scheduledTasksCronPropertiesConfig() {
		logger.info("scheduledTasksCronPropertiesConfig executed at {}", LocalDateTime.now());
	}

	public void doKpiCheck() {

		// Get PreQual job list.
		// select * from ppmsdm.rawmat_monitor_result Where ROWNUM <= 100;
		/// Map<String, List<RawmatMonitorResult>> => Map<Case_ID,
		// List<RawmatMonitorResult>>
		Map<String, List<RawmatMonitorResult>> tmp = new HashMap<String, List<RawmatMonitorResult>>();
		tmp = getTheEarliestJobs();

		// forEach
		for (Map.Entry<String, List<RawmatMonitorResult>> entry : tmp.entrySet()) {

			System.out.println("key:" + entry.getKey() + ",value:" + entry.getValue());

			List<RawmatMonitorResult> curJobList = entry.getValue();

			for (Iterator<RawmatMonitorResult> iterator = curJobList.iterator(); iterator.hasNext();) {
				RawmatMonitorResult curMonJob = iterator.next();
				IKpiMonitor curKpiMonEntity = null;

				switch (curMonJob.getJOB_STATUS()) {
				case "2":
					curKpiMonEntity = getKpiMonitorEntity(curMonJob.getMEAS_DATA_TYPE());
					break;

				case "6":

					break;

				case "8":

					break;

				default:

					break;
				}

			}

		}

	}

	private IKpiMonitor getKpiMonitorEntity(String _measDataType) {

		// TODO Auto-generated method stub
		return null;
	}

	private Map<String, List<RawmatMonitorResult>> getTheEarliestJobs() {

		// TODO Auto-generated method stub
		return null;
		// return Collections.singletonMap("username1", "password1");
	}


}
