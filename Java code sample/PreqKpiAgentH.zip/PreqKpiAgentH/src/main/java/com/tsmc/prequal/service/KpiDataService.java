package com.tsmc.prequal.service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonProcessingException;
//import com.fasterxml.jackson.databind.ObjectMapper;

import com.tsmc.prequal.dao.PreBatchStatusDao;
import com.tsmc.prequal.dao.PreqMonitorResultDao;
import com.tsmc.prequal.data.model.dto.MonitorCriteriaVo;
import com.tsmc.prequal.data.model.po.RawmatMonitorResult;
import com.tsmc.prequal.data.model.po.RawmatPreBatchStatus;
import com.tsmc.prequal.utils.StringUtils;


/// @Component is required for scheduling
@Component
public class KpiDataService {

	private Logger LOG = LoggerFactory.getLogger(KpiDataService.class);
	
	@Value( "${kpiAgent.fabName}" )
	private String FabName; 
	
	@Autowired
	private PreBatchStatusDao preqCaseDao; 
	
	@Autowired
	private PreqMonitorResultDao preqMonRsltDao; 

	@Scheduled(cron = "${scheduledTasksCronPropertiesConfig.cron.expression}")
	public void scheduledTasksCronPropertiesConfig() throws JsonProcessingException {
		
		/// TODO: Change to Java get method.name 
		String curMehtod = "scheduledTasksCronPropertiesConfig"; 
		LOG.info(String.format("[%s] executed at %s", curMehtod, LocalDateTime.now()));
		
		//ObjectMapper jsonObjectMapper = new ObjectMapper(); 
		
		goInitialTest(); 
		
		Map<String, RawmatPreBatchStatus> kpiCaseMap = new HashMap<String, RawmatPreBatchStatus> (); 
		kpiCaseMap = getEarliestCases(); 
		
		if(kpiCaseMap == null || kpiCaseMap.size() < 1) {
			LOG.info(String.format("[%s] Can't find any PreQual KPI cases...", curMehtod));
			return; 
		}		
		
		for (Map.Entry<String, RawmatPreBatchStatus> entry : kpiCaseMap.entrySet()) {
			
			try {
				
				LOG.info(String.format("Start to process caseId: %s, value:%s", entry.getKey(), StringUtils.writeAsJson(entry.getValue())));
				
				
			} catch (JsonProcessingException e) { /// JsonProcessingException
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (Exception ex) {
				LOG.info(String.format("[%s] Exception: %s, \n%s", ex.getMessage(), ex.getStackTrace()));
			} catch (Error err) {
				LOG.info(String.format("[%s] Error: %s, \n%s", err.getMessage(), err.getStackTrace()));
			}

		}
		
	}

	public void doKpiCheck(RawmatPreBatchStatus _curKpiBatch) {

		
		List<RawmatMonitorResult> kpiJobList = new ArrayList<RawmatMonitorResult>(); 
		kpiJobList = getTheEarliestJobs(_curKpiBatch.getCaseId());
		
		for (Iterator<RawmatMonitorResult> iterator = kpiJobList.iterator(); iterator.hasNext();) {
			
			RawmatMonitorResult curMonJob = iterator.next();
			IKpiMonitor curKpiMonEntity = null;

			switch (curMonJob.getJobStatus()) {
			case "2":
				curKpiMonEntity = getKpiMonitorEntity(curMonJob.getMeasDataType());
				break;

			case "6":

				break;

			case "8":

				break;

			default:

				break;
			}

		}
		

	}

	private Map<String, RawmatPreBatchStatus> getEarliestCases() {
		// TODO Auto-generated method stub
		return null;
	}

	private IKpiMonitor getKpiMonitorEntity(String _measDataType) {

		// TODO Auto-generated method stub
		return null;
	}

	private List<RawmatMonitorResult> getTheEarliestJobs(Long _caseId) {
		
		List<RawmatMonitorResult> _rtnJobList = preqMonRsltDao.findAllByCaseId(_caseId); 
		
		return _rtnJobList;
		// return Collections.singletonMap("username1", "password1");
	}


	
	private void goInitialTest() throws JsonProcessingException {
		/// TODO: Change to Java get method.name 
		String curMehtod = "goInitialTest"; 
		LOG.info(String.format("[%s] executed at %s", curMehtod, LocalDateTime.now()));
		
		MonitorCriteriaVo tmp = new MonitorCriteriaVo(); 
		tmp.setMatNo("L144568");
		LOG.info(String.format("[%s] StringUtils.writeAsJson: %s", curMehtod, StringUtils.writeAsJson(tmp)));
		
		String tmpJson = "{\"fabName\":null,\"matPhaseId\":null,\"plantCode\":null,\"matNo\":\"L144568\",\"batchId\":null,\"contrId\":null,\"matChangeTime\":null,\"matUsedTime\":null,\"ntAccount\":\"YCWENGC\",\"chartTitle\":null,\"criteria\":null}"; 
		tmp = (MonitorCriteriaVo) StringUtils.readFromJson(tmpJson, MonitorCriteriaVo.class ); 
		LOG.info(String.format("[%s] StringUtils.readFromJson: %s, %s", curMehtod, tmp.getMatNo(), tmp.getNtAccount()));
		
	}
}
