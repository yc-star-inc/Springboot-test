package com.tsmc.prequal.service;

import java.util.List;

import com.tsmc.prequal.data.model.dto.KpiDataPointVo;
import com.tsmc.prequal.data.model.po.RawmatMonitorResult;

public interface IKpiMonitor {
	
	public void setMonitorJob(String _caseId, RawmatMonitorResult _curMonJob); 
	public List<KpiDataPointVo> getTargetDataSet(); 
	
	
}
