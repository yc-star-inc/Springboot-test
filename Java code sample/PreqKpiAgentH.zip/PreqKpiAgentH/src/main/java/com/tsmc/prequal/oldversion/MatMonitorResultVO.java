package com.tsmc.prequal.oldversion;

public class MatMonitorResultVO {

	public ResultRawVO getResultRaw() {
		// TODO Auto-generated method stub
		return null;
	}

}
