package com.tsmc.prequal.data.model.dto;

import java.util.Map;

public class KpiMonitorBasicVo {
	String fabName;
	String matPhaseId;
	String plantCode;
	String matNo;
	String batchId;
	String contrId;
	String matChangeTime;
	String matUsedTime;
	String ntAccount;
	String chartTitle;
	Map<String, String> criteria; // ${chartId}

	public String getFabName() {
		return fabName;
	}

	public void setFabName(String fabName) {
		this.fabName = fabName;
	}

	public String getMatPhaseId() {
		return matPhaseId;
	}

	public void setMatPhaseId(String matPhaseId) {
		this.matPhaseId = matPhaseId;
	}

	public String getPlantCode() {
		return plantCode;
	}

	public void setPlantCode(String plantCode) {
		this.plantCode = plantCode;
	}

	public String getMatNo() {
		return matNo;
	}

	public void setMatNo(String matNo) {
		this.matNo = matNo;
	}

	public String getBatchId() {
		return batchId;
	}

	public void setBatchId(String batchId) {
		this.batchId = batchId;
	}

	public String getContrId() {
		return contrId;
	}

	public void setContrId(String contrId) {
		this.contrId = contrId;
	}

	public String getMatChangeTime() {
		return matChangeTime;
	}

	public void setMatChangeTime(String matChangeTime) {
		this.matChangeTime = matChangeTime;
	}

	public String getMatUsedTime() {
		return matUsedTime;
	}

	public void setMatUsedTime(String matUsedTime) {
		this.matUsedTime = matUsedTime;
	}

	public String getNtAccount() {
		return ntAccount;
	}

	public void setNtAccount(String ntAccount) {
		this.ntAccount = ntAccount;
	}

	public String getChartTitle() {
		return chartTitle;
	}

	public void setChartTitle(String chartTitle) {
		this.chartTitle = chartTitle;
	}

	public Map<String, String> getCriteria() {
		return criteria;
	}

	public void setCriteria(Map<String, String> criteria) {
		this.criteria = criteria;
	}

}
