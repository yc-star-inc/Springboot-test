package com.tsmc.prequal.data.model.dto;

import java.util.Map;

public class MatchingResultVo {

	private String matchingResult = ""; 
	private String memo = "";
	
	public String getMatchingResult() {
		return matchingResult;
	}
	public void setMatchingResult(String matchingResult) {
		this.matchingResult = matchingResult;
	}
	public String getMemo() {
		return memo;
	}
	public void setMemo(String memo) {
		this.memo = memo;
	} 
	
}
