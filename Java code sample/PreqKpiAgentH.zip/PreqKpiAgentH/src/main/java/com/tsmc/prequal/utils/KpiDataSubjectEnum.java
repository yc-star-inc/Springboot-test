package com.tsmc.prequal.utils;

public enum KpiDataSubjectEnum {
	SPC, FAC, iDS
}
