package com.tsmc.prequal.data.model.dto;

public class KpiMatchResultVo {

}
