package com.tsmc.prequal.data.model.po;

import java.nio.charset.StandardCharsets;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.tsmc.prequal.data.model.dto.MonitorCriteriaVo;
import com.tsmc.prequal.utils.DateUtils;

//import com.fasterxml.jackson.annotation.JsonFormat;

public class RawmatMonitorResult {

	public static String writeAsJson(RawmatMonitorResult _curObj) throws JsonProcessingException {
		ObjectMapper objectMapper = new ObjectMapper();
		objectMapper.setDateFormat(DateUtils.DateTimeFormat);
		return objectMapper.writeValueAsString(_curObj);
	}

	public static RawmatMonitorResult readFromJson(String _jsonString) throws JsonProcessingException {
		ObjectMapper objectMapper = new ObjectMapper();
		RawmatMonitorResult rtnObj = objectMapper.readValue(_jsonString, RawmatMonitorResult.class);
		return rtnObj;
	}

	@Column(name = "JOB_ID")
	private Integer jobId;

	@Column(name = "CASE_ID")
	private Integer caseId;

	@Column(name = "FAB_NAME")
	private String fabName;

	@Column(name = "PHASE_ID")
	private String phaseId;

	@Column(name = "SECT_CD")
	private String sectCode;

	
	private String monitorCriteria;
	
	@Column(name = "MONITOR_CRI")
	private byte[] monitorCriBytes; 


	@Column(name = "RESULT_RAW")
	private String[] resultRaw;

	@Column(name = "RESULT_PATH")
	private String[] resultPath;

	@Column(name = "JOB_STATUS")
	private String jobStatus;

	@Column(name = "SUBMIT_FA_RESULT")
	private String[] submitFaResult;

	@Column(name = "MONITOR_RESULT")
	private String[] monitorResult;

	@Column(name = "MEAS_DATA_TYPE")
	private String measDataType;

	// @JsonFormat(pattern = "yyyy/MM/dd HH:mm:ss")
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "LAST_CHK_DT")
	private Timestamp lastCheckTime;

	@Column(name = "MAIN_CRTRN")
	private String mainCriteria;

	@Column(name = "SUB_CRTRN")
	private String subCriteria;

	@Column(name = "PARM")
	private String parm;

	@Column(name = "EXEC_HIST")
	private String[] execHist;

	public Integer getJobId() {
		return jobId;
	}

	public void setJobId(Integer jobId) {
		this.jobId = jobId;
	}

	public Integer getCaseId() {
		return caseId;
	}

	public void setCaseId(Integer caseId) {
		this.caseId = caseId;
	}

	public String getFabName() {
		return fabName;
	}

	public void setFabName(String fabName) {
		this.fabName = fabName;
	}

	public String getPhaseId() {
		return phaseId;
	}

	public void setPhaseId(String phaseId) {
		this.phaseId = phaseId;
	}

	public String getSectCode() {
		return sectCode;
	}

	public void setSectCode(String sectCode) {
		this.sectCode = sectCode;
	}

	public String getMonitorCriteria() {
		String tmpString = ""; 
		if(this.getMonitorCri() != null)
			tmpString = new String(this.getMonitorCri(), StandardCharsets.UTF_8);
		return tmpString;
	}

	public void setMonitorCriteria(String monitorCriteria) {
		this.monitorCriteria = monitorCriteria;
		byte[] monCriBytes = monitorCriteria.getBytes(StandardCharsets.UTF_8);
		this.setMonitorCri(monCriBytes);
		
	}

	public String[] getResultRaw() {
		return resultRaw;
	}

	public void setResultRaw(String[] resultRaw) {
		this.resultRaw = resultRaw;
	}

	public String[] getResultPath() {
		return resultPath;
	}

	public void setResultPath(String[] resultPath) {
		this.resultPath = resultPath;
	}

	public String getJobStatus() {
		return jobStatus;
	}

	public void setJobStatus(String jobStatus) {
		this.jobStatus = jobStatus;
	}

	public String[] getSubmitFaResult() {
		return submitFaResult;
	}

	public void setSubmitFaResult(String[] submitFaResult) {
		this.submitFaResult = submitFaResult;
	}

	public String getMeasDataType() {
		return measDataType;
	}

	public void setMeasDataType(String measDataType) {
		this.measDataType = measDataType;
	}

	public Timestamp getLastCheckTime() {
		return lastCheckTime;
	}

	public void setLastCheckTime(Timestamp lastCheckTime) {
		this.lastCheckTime = lastCheckTime;
	}

	public String getMainCriteria() {
		return mainCriteria;
	}

	public void setMainCriteria(String mainCriteria) {
		this.mainCriteria = mainCriteria;
	}

	public String getSubCriteria() {
		return subCriteria;
	}

	public void setSubCriteria(String subCriteria) {
		this.subCriteria = subCriteria;
	}	

	public byte[] getMonitorCri() {
		return monitorCriBytes;
	}

	public void setMonitorCri(byte[] monitorCriBytes) {
		this.monitorCriBytes = monitorCriBytes;
	}
	

	public String getParm() {
		return parm;
	}

	public void setParm(String parm) {
		this.parm = parm;
	}

	public String[] getExecHist() {
		return execHist;
	}

	public void setExecHist(String[] execHist) {
		this.execHist = execHist;
	}

	public String[] getMonitorResult() {
		return monitorResult;
	}

	public void setMonitorResult(String[] monitorResult) {
		this.monitorResult = monitorResult;
	}

}
