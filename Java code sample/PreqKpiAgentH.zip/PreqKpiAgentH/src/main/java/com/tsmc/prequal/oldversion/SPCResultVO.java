package com.tsmc.prequal.oldversion;

import java.util.List;
import java.util.Map;

import com.tsmc.prequal.data.model.po.RawmatMonitorResult;

public class SPCResultVO {

	public List<RawmatMonitorResult> getRawData() {
		// TODO Auto-generated method stub
		return null;
	}


}
