package com.tsmc.prequal.oldversion;

public class Constant {
	public static String LOOP_INLINE = "inline"; 
	public static String LOOP_OFFLINE = "offline"; 
}
