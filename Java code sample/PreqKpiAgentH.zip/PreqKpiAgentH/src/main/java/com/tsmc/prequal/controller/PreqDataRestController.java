package com.tsmc.prequal.controller;

import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicLong;

import com.tsmc.prequal.data.model.dto.KpiResultPathVo;
import com.tsmc.prequal.data.model.po.Greeting;

@RestController
public class PreqDataRestController {

	private static final String template = "Hello, %s!";
	private final AtomicLong counter = new AtomicLong();
	
	@GetMapping("/greeting")
	public Greeting greeting(@RequestParam(value = "name", defaultValue = "World") String name) 
	{
		return new Greeting(counter.incrementAndGet(), String.format(template, name));
	}
	@GetMapping("/hello")
	public String hello(@RequestParam(value = "name", defaultValue = "World") String name) 
	{
		return String.format(template, name);
	}
	
	@GetMapping("/getResultPath")
	public KpiResultPathVo getResultPath(@RequestParam(value = "name", defaultValue = "World") String name) 
	{
		List<String> facTagList = new ArrayList<String>(); 
		facTagList.add("123"); 
		String facTagString = "1234"; 
		
		String imgSaoId = ""; 
		String imgUrl = ""; 
		String rawDataSaoId = ""; 
		String rawDataStartDate = ""; 
		String rawDataEndDate = ""; 
		
		String targetStartDate = ""; 
		String targetEndDate = "";
		
		Map<String, String> criteria = new HashMap<String, String>(); 
		criteria.put("facTag", facTagString); 
		
		return new KpiResultPathVo(imgSaoId, imgUrl, rawDataSaoId, rawDataStartDate, rawDataEndDate, targetStartDate, targetEndDate, criteria);
		// https://spring.io/guides/gs/rest-service/
	}
	
	
}
