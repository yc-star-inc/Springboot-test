package com.tsmc.prequal.service;

import java.util.List;

import com.tsmc.prequal.data.model.dto.MatchingResultVo;
import com.tsmc.prequal.data.model.po.RawmatMonitorResult;
import com.tsmc.prequal.service.dto.IKpiJobAction;
import com.tsmc.prequal.service.dto.KpiCheckResultVo;
import com.tsmc.prequal.utils.KpiDataSubjectEnum;

public class FacKpiJobAction implements IKpiJobAction {

	public FacKpiJobAction() {
		// TODO Auto-generated constructor stub
	}


	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}


	@Override
	public KpiCheckResultVo getKpiCriteria(KpiDataSubjectEnum dataSubject, RawmatMonitorResult curMonJob) {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public KpiCheckResultVo doKpiCheck(KpiDataSubjectEnum dataSubject, RawmatMonitorResult curMonJob) {
		// TODO Auto-generated method stub
		return null;
	}

}
