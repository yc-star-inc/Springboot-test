package com.tsmc.prequal.oldversion;

import java.util.List;

public class FindLeadingLotDao {

	public List<MatMonitorResultVO> queryMonitorResult(String fabName, String caseId, String lOOP_INLINE) {
		// TODO Auto-generated method stub
		return null;
	}

}
