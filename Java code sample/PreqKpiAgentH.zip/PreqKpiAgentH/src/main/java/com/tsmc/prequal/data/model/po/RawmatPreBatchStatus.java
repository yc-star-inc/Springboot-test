package com.tsmc.prequal.data.model.po;

public class RawmatPreBatchStatus {

}
