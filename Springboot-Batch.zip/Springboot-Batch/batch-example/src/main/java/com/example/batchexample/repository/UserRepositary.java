/**
 * 
 */
package com.example.batchexample.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.batchexample.model.User;


public interface UserRepositary extends JpaRepository<User, Integer>{

}
