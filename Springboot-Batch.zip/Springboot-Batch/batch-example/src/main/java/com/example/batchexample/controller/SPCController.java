package com.example.batchexample.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/SPC")
public class SPCController {
	
	@RequestMapping("/hello")
	public String hello() {
		return "Hey, please remember to implement this function"; 
	}

}
