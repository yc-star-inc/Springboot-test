package com.example.batchexample;

import java.io.PrintStream;

import org.springframework.boot.Banner;
import org.springframework.boot.ResourceBanner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.core.env.Environment;
import org.springframework.core.io.ClassPathResource;

@SpringBootApplication
public class BatchExampleApplication {

	public static void main(String[] args) {
		//SpringApplication.run(BatchExampleApplication.class, args);
		
		SpringApplication bootstrap = new SpringApplication(BatchExampleApplication.class); 
		bootstrap.setBanner(
				new ResourceBanner(new ClassPathResource("banner.txt"))

				//new Banner() 
				//{ 
				//	@Override 
				//	public void printBanner(Environment environment, Class<?> sourceClass, PrintStream out) 
				//	{ 
				//		// 比如列印一個我們喜歡的ASCII Arts字符畫 } });
				//      // http://www.network-science.de/ascii/
				//	}
				//}
			); 
		bootstrap.setBannerMode(Banner.Mode.CONSOLE);
		bootstrap.run(args);
	}
}