package com.example.batchexample;

import java.io.PrintStream;
import java.util.Iterator;
import java.util.List;

import org.springframework.boot.Banner;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.ResourceBanner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.core.env.Environment;
import org.springframework.core.io.ClassPathResource;

import com.example.batchexample.model.User;
import com.example.batchexample.repository.UserRepositary;

@SpringBootApplication
public class BatchExampleApplication {
//public class BatchExampleApplication implements CommandLineRunner{
	
	public static void main(String[] args) {
		//SpringApplication.run(BatchExampleApplication.class, args);
		
		SpringApplication bootstrap = new SpringApplication(BatchExampleApplication.class); 
		bootstrap.setBanner(
				new ResourceBanner(new ClassPathResource("banner.txt"))

				//new Banner() 
				//{ 
				//	@Override 
				//	public void printBanner(Environment environment, Class<?> sourceClass, PrintStream out) 
				//	{ 
				//		// 比如列印一個我們喜歡的ASCII Arts字符畫 } });
				//      // http://www.network-science.de/ascii/
				//	}
				//}
			); 
		bootstrap.setBannerMode(Banner.Mode.CONSOLE);
		bootstrap.run(args);
	}

	/*
	private UserRepositary repo; 
	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		repo.save(new User(12,"David", "RD", 10000)); 
		repo.save(new User(13,"Lai", "RD", 10000)); 
		
		List<User> user = repo.findAll(); 
		Iterator<User> itr = user.iterator(); 
		while(itr.hasNext()) {
			System.out.println(itr.next().toString());
			
		}
	}
	//*/
}