package com.example.batchexample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BatchExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
