package com.tsmc.prequal;

import org.apache.logging.log4j.Logger;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;

@SpringBootApplication
//@SpringBootApplication(exclude= {DataSourceAutoConfiguration.class})
public class SalseManagerApplication {

	private Logger LOG;
	public String VERSION = "1.0.1"; 
	
	public static void main(String[] args) {
		SpringApplication.run(SalseManagerApplication.class, args);
	}

}
