package com.tsmc.prequal.data.model.po;

import java.sql.Timestamp;

import com.fasterxml.jackson.annotation.JsonFormat;

public class RawmatMonitorResult {
	
	 Integer JOB_ID; 
	 Integer CASE_ID; 
	 String FAB_NAME; 
	 String PHASE_ID; 
	 String SECT_CD; 
	 String MONITOR_CRI; 
	 String RESULT_RAW; 
	 String RESULT_PATH; 
	 String JOB_STATUS; 
	 String SUBMIT_FA_RESULT; 
	 String MEAS_DATA_TYPE; 
	 
	 //@JsonFormat(pattern = "yyyy/MM/dd HH:mm:ss")
	 Timestamp LAST_CHK_DT; 
	 
	 String MAIN_CRTRN; 
	 String SUB_CRTRN; 
	 String PARM; 
	 String EXEC_HIST; 
	 
	 //@JsonFormat(pattern = "yyyy/MM/dd HH:mm:ss")
	 Timestamp CREATE_DT;
	 
	public Integer getJOB_ID() {
		return JOB_ID;
	}
	public void setJOB_ID(Integer jOB_ID) {
		JOB_ID = jOB_ID;
	}
	public Integer getCASE_ID() {
		return CASE_ID;
	}
	public void setCASE_ID(Integer cASE_ID) {
		CASE_ID = cASE_ID;
	}
	public String getFAB_NAME() {
		return FAB_NAME;
	}
	public void setFAB_NAME(String fAB_NAME) {
		FAB_NAME = fAB_NAME;
	}
	public String getPHASE_ID() {
		return PHASE_ID;
	}
	public void setPHASE_ID(String pHASE_ID) {
		PHASE_ID = pHASE_ID;
	}
	public String getSECT_CD() {
		return SECT_CD;
	}
	public void setSECT_CD(String sECT_CD) {
		SECT_CD = sECT_CD;
	}
	public String getMONITOR_CRI() {
		return MONITOR_CRI;
	}
	public void setMONITOR_CRI(String mONITOR_CRI) {
		MONITOR_CRI = mONITOR_CRI;
	}
	public String getRESULT_RAW() {
		return RESULT_RAW;
	}
	public void setRESULT_RAW(String rESULT_RAW) {
		RESULT_RAW = rESULT_RAW;
	}
	public String getRESULT_PATH() {
		return RESULT_PATH;
	}
	public void setRESULT_PATH(String rESULT_PATH) {
		RESULT_PATH = rESULT_PATH;
	}
	public String getJOB_STATUS() {
		return JOB_STATUS;
	}
	public void setJOB_STATUS(String jOB_STATUS) {
		JOB_STATUS = jOB_STATUS;
	}
	public String getSUBMIT_FA_RESULT() {
		return SUBMIT_FA_RESULT;
	}
	public void setSUBMIT_FA_RESULT(String sUBMIT_FA_RESULT) {
		SUBMIT_FA_RESULT = sUBMIT_FA_RESULT;
	}
	public String getMEAS_DATA_TYPE() {
		return MEAS_DATA_TYPE;
	}
	public void setMEAS_DATA_TYPE(String mEAS_DATA_TYPE) {
		MEAS_DATA_TYPE = mEAS_DATA_TYPE;
	}
	public Timestamp getLAST_CHK_DT() {
		return LAST_CHK_DT;
	}
	public void setLAST_CHK_DT(Timestamp lAST_CHK_DT) {
		LAST_CHK_DT = lAST_CHK_DT;
	}
	public String getMAIN_CRTRN() {
		return MAIN_CRTRN;
	}
	public void setMAIN_CRTRN(String mAIN_CRTRN) {
		MAIN_CRTRN = mAIN_CRTRN;
	}
	public String getSUB_CRTRN() {
		return SUB_CRTRN;
	}
	public void setSUB_CRTRN(String sUB_CRTRN) {
		SUB_CRTRN = sUB_CRTRN;
	}
	public String getPARM() {
		return PARM;
	}
	public void setPARM(String pARM) {
		PARM = pARM;
	}
	public String getEXEC_HIST() {
		return EXEC_HIST;
	}
	public void setEXEC_HIST(String eXEC_HIST) {
		EXEC_HIST = eXEC_HIST;
	}
	public Timestamp getCREATE_DT() {
		return CREATE_DT;
	}
	public void setCREATE_DT(Timestamp cREATE_DT) {
		CREATE_DT = cREATE_DT;
	} 

	 
}
