package com.javatechie.tx;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FlightServiceExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
