package com.tsmc.ecp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SalseManagerApplicationTests {

	@Test
	void contextLoads() {
	}

}
